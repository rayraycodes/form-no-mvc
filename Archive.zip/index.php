<?php
// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "webtech_registration");

function getAvailableSlots($conn) {
    // Query to get the count of registrations for each timeslot
    $sql = "SELECT time_slot, COUNT(*) as count FROM student_registrations GROUP BY time_slot";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Initialize an array to hold the count of registrations for each timeslot
        $registrations = array_fill(1, 6, 0);

        while ($row = mysqli_fetch_assoc($result)) {
            $registrations[$row['time_slot']] = $row['count'];
        }

        // Calculate the available slots for each timeslot
        $availableSlots = array_map(function($count) {
            return 6 - $count;
        }, $registrations);

        return $availableSlots;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        return false;
    }
}

$availableSlots = getAvailableSlots($conn);
?>


<!DOCTYPE html>
<html>
<head>
    <title>Web Technology Class Registration</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Web Technology Class Registration</h1>
        <form action="registration.php" method="post">
            <label for="id">Student ID:</label>
            <input type="text" id="id" name="id" required>

            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" required>

            <label for="projecttitle">Project Title:</label>
            <input type="text" id="projecttitle" name="projecttitle" required>

            <label for="email">Email Address:</label>
            <input type="text" id="email" name="email" required>

            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required>

            <!-- Your HTML form -->
            <label for="timeslot">Select Time Slot:</label>
            <select id="timeslot" name="timeslot">
                <?php
                for ($i = 1; $i <= 6; $i++) {
                    echo "<option value='$i'>4/19/2070, " . (($i % 3) + 6) . ":00 PM – " . (($i % 3) + 7) . ":00 PM, {$availableSlots[$i]} seats remaining</option>";
                }
                ?>
            </select>

            <input type="submit" value="Register">
        </form>
    </div>
</body>
</html>